<h3>إدارة المستخدمين</h3>
<a href="/users/create">إضافة مستخدم</a>
<table border="1">
<tr><th>الاسم</th><th>المستخدم</th><th>الدور</th></tr>
@foreach($users as $u)
<tr><td>{{ $u->name }}</td><td>{{ $u->username }}</td><td>{{ $u->role }}</td></tr>
@endforeach
</table>
