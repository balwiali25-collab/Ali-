<h3>إضافة مستخدم</h3>
<form method="POST" action="/users">@csrf
<input name="name" placeholder="الاسم">
<input name="username" placeholder="اسم المستخدم">
<input type="password" name="password" placeholder="كلمة المرور">
<select name="role">
<option value="admin">أدمن</option>
<option value="cashier">كاشير</option>
</select>
<button>حفظ</button>
</form>
