<h3>متجر هواتف الحيدرة</h3>
<form method="POST">@csrf
<input name="username" placeholder="اسم المستخدم">
<input type="password" name="password" placeholder="كلمة المرور">
<button>دخول</button>
</form>
