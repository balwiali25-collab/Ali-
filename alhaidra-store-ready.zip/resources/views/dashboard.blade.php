<h3>لوحة التحكم – متجر هواتف الحيدرة</h3>
@if(auth()->user()->role==='admin')
<a href="/users">إدارة المستخدمين</a>
@endif
<br><a href="/logout">تسجيل خروج</a>
