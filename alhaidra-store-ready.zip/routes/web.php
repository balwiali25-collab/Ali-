<?php
use App\Http\Controllers\AuthController;
use App\Http\Controllers\UserController;

Route::get('/login',[AuthController::class,'login']);
Route::post('/login',[AuthController::class,'doLogin']);
Route::get('/logout',[AuthController::class,'logout']);

Route::middleware('auth')->group(function(){
    Route::get('/dashboard',function(){ return view('dashboard'); });

    Route::middleware('admin')->group(function(){
        Route::get('/users',[UserController::class,'index']);
        Route::get('/users/create',[UserController::class,'create']);
        Route::post('/users',[UserController::class,'store']);
    });
});
